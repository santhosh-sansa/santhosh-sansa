"""MCP resources package."""
