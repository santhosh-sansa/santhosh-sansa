# Quantum currency package initialization
