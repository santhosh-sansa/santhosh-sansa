# Configuration package initialization
