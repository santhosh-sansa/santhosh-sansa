"""
GitHub tests package initialization.
"""