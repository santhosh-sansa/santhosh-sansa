"""
AWS tests package initialization.
"""