"""
Core tests package initialization.
"""