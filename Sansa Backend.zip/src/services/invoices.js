const fs = require('fs/promises');
const path = require('path');
const { pool, query } = require('./db');

const dataDir = path.join(__dirname, '..', '..', 'data');
const invoicesPath = path.join(dataDir, 'invoices.json');

function numberValue(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

async function readJson(filePath, fallback) {
  try {
    return JSON.parse(await fs.readFile(filePath, 'utf8'));
  } catch (error) {
    return fallback;
  }
}

async function writeJson(filePath, value) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, JSON.stringify(value, null, 2));
}

function warnNonCriticalWrite(error, label) {
  if (process.env.NODE_ENV !== 'test') {
    console.warn(`SANSA ${label} skipped: ${error.message}`);
  }
}

function normalizeInvoiceRecord(userId, invoice = {}) {
  const totals = invoice.totals || {};
  const meta = invoice.meta || {};
  const customer = invoice.customer || {};
  return {
    id: invoice.id || `invoice-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
    userId: String(userId || 'guest'),
    invoiceNumber: String(meta.invoiceNumber || invoice.invoiceNumber || `SANSA-${Date.now()}`),
    customerName: String(customer.name || invoice.customerName || ''),
    customerContact: String(customer.contact || invoice.customerContact || ''),
    subtotal: numberValue(totals.subtotal),
    tax: numberValue(totals.tax),
    discount: numberValue(totals.discount),
    total: numberValue(totals.total),
    paidAmount: numberValue(meta.paidAmount),
    balance: numberValue(meta.balance),
    status: String(meta.status || invoice.status || 'pending'),
    paymentUrl: String(invoice.paymentUrl || ''),
    reminderText: String(invoice.reminderText || ''),
    invoiceJson: invoice,
    createdAt: new Date().toISOString(),
  };
}

async function saveInvoiceRecord(userId, invoice = {}) {
  const record = normalizeInvoiceRecord(userId, invoice);

  if (pool) {
    try {
      const result = await query(
        `INSERT INTO invoice_records
          (user_id, invoice_number, customer_name, customer_contact, subtotal, tax, discount, total,
           paid_amount, balance, status, payment_url, reminder_text, invoice_json)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
         RETURNING id, created_at`,
        [
          record.userId,
          record.invoiceNumber,
          record.customerName,
          record.customerContact,
          record.subtotal,
          record.tax,
          record.discount,
          record.total,
          record.paidAmount,
          record.balance,
          record.status,
          record.paymentUrl,
          record.reminderText,
          JSON.stringify(record.invoiceJson),
        ]
      );
      return {
        ...record,
        id: String(result.rows[0]?.id || record.id),
        createdAt: result.rows[0]?.created_at || record.createdAt,
      };
    } catch (error) {
      warnNonCriticalWrite(error, 'invoice database write');
    }
  }

  try {
    const invoices = await readJson(invoicesPath, []);
    invoices.unshift(record);
    await writeJson(invoicesPath, invoices.slice(0, 1000));
  } catch (error) {
    warnNonCriticalWrite(error, 'invoice file write');
  }

  return record;
}

async function listInvoiceRecords(userId = 'guest', limit = 25) {
  const safeLimit = Math.min(Math.max(Number(limit) || 25, 1), 100);
  if (pool) {
    const result = await query(
      `SELECT id, user_id, invoice_number, customer_name, customer_contact, subtotal, tax, discount,
              total, paid_amount, balance, status, payment_url, reminder_text, created_at
       FROM invoice_records
       WHERE user_id = $1
       ORDER BY created_at DESC
       LIMIT $2`,
      [String(userId || 'guest'), safeLimit]
    );
    return result.rows.map((row) => ({
      id: String(row.id),
      userId: row.user_id,
      invoiceNumber: row.invoice_number,
      customerName: row.customer_name,
      customerContact: row.customer_contact,
      subtotal: numberValue(row.subtotal),
      tax: numberValue(row.tax),
      discount: numberValue(row.discount),
      total: numberValue(row.total),
      paidAmount: numberValue(row.paid_amount),
      balance: numberValue(row.balance),
      status: row.status,
      paymentUrl: row.payment_url,
      reminderText: row.reminder_text,
      createdAt: row.created_at,
    }));
  }

  const invoices = await readJson(invoicesPath, []);
  return invoices.filter((invoice) => invoice.userId === String(userId || 'guest')).slice(0, safeLimit);
}

module.exports = {
  saveInvoiceRecord,
  listInvoiceRecords,
};
