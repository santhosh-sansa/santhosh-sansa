const fs = require('fs/promises');
const path = require('path');
const { PDFDocument } = require('pdf-lib');

const uploadsDir = path.join(__dirname, '..', '..', 'uploads');

function cleanName(value = 'sansa-pdf') {
  return String(value || 'sansa-pdf')
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80) || 'sansa-pdf';
}

function normalizeAction(value = '') {
  const action = String(value || '').trim().toLowerCase();
  if (['split', 'extract', 'extract-pages'].includes(action)) return 'split';
  return 'merge';
}

function parsePageSelection(value = '', pageCount = 0) {
  const text = String(value || '').trim();
  if (!text) return Array.from({ length: pageCount }, (_, index) => index);
  const selected = new Set();
  for (const part of text.split(',')) {
    const token = part.trim();
    if (!token) continue;
    const range = token.match(/^(\d+)\s*-\s*(\d+)$/);
    if (range) {
      const start = Math.max(1, Number(range[1]));
      const end = Math.min(pageCount, Number(range[2]));
      for (let page = Math.min(start, end); page <= Math.max(start, end); page += 1) {
        if (page >= 1 && page <= pageCount) selected.add(page - 1);
      }
      continue;
    }
    const page = Number(token);
    if (Number.isInteger(page) && page >= 1 && page <= pageCount) selected.add(page - 1);
  }
  return [...selected].sort((a, b) => a - b);
}

async function loadPdf(file) {
  const bytes = await fs.readFile(file.path);
  const pdf = await PDFDocument.load(bytes, { ignoreEncryption: true });
  return {
    file,
    pdf,
    pageCount: pdf.getPageCount(),
  };
}

function fileSummary(loaded) {
  return loaded.map((item) => ({
    name: item.file.originalname || item.file.filename,
    size: item.file.size || 0,
    pages: item.pageCount,
  }));
}

async function writeOutput(pdfDoc, prefix) {
  await fs.mkdir(uploadsDir, { recursive: true });
  const outputName = `${cleanName(prefix)}-${Date.now()}.pdf`;
  const outputPath = path.join(uploadsDir, outputName);
  const outputBytes = await pdfDoc.save();
  await fs.writeFile(outputPath, outputBytes);
  return {
    outputName,
    outputPath,
    outputUrl: `/uploads/${outputName}`,
    outputBytes: outputBytes.length,
  };
}

async function mergePdfs(loaded, body = {}) {
  const output = await PDFDocument.create();
  let copiedPages = 0;
  for (const item of loaded) {
    const pageIndexes = Array.from({ length: item.pageCount }, (_, index) => index);
    const pages = await output.copyPages(item.pdf, pageIndexes);
    pages.forEach((page) => output.addPage(page));
    copiedPages += pages.length;
  }
  const written = await writeOutput(output, body.outputName || 'sansa-merged-pdf');
  return {
    title: 'Advanced PDF Merge',
    action: 'merge',
    pages: copiedPages,
    ...written,
  };
}

async function splitPdf(loaded, body = {}) {
  if (loaded.length !== 1) {
    const error = new Error('Split/extract needs exactly one source PDF.');
    error.status = 422;
    throw error;
  }
  const source = loaded[0];
  const selectedPages = parsePageSelection(body.pageRanges, source.pageCount);
  if (!selectedPages.length) {
    const error = new Error('No valid pages selected.');
    error.status = 422;
    throw error;
  }
  const output = await PDFDocument.create();
  const pages = await output.copyPages(source.pdf, selectedPages);
  pages.forEach((page) => output.addPage(page));
  const written = await writeOutput(output, body.outputName || 'sansa-split-pdf');
  return {
    title: 'Advanced PDF Split / Extract',
    action: 'split',
    pages: selectedPages.length,
    pageRanges: String(body.pageRanges || 'all pages'),
    ...written,
  };
}

async function runPdfStudio(body = {}, files = []) {
  const pdfFiles = (files || []).filter((file) => /pdf/i.test(file.mimetype || '') || /\.pdf$/i.test(file.originalname || ''));
  if (!pdfFiles.length) {
    const error = new Error('Upload at least one PDF file.');
    error.status = 422;
    throw error;
  }

  const action = normalizeAction(body.action || body.toolId);
  if (action === 'merge' && pdfFiles.length < 2) {
    const error = new Error('Merge needs two or more PDF files.');
    error.status = 422;
    throw error;
  }

  const loaded = await Promise.all(pdfFiles.map(loadPdf));
  const result = action === 'split'
    ? await splitPdf(loaded, body)
    : await mergePdfs(loaded, body);
  const filesSummary = fileSummary(loaded);
  const text = [
    `SANSA ${result.title} - Real PDF Output`,
    '',
    `Action: ${result.action}`,
    `Input files: ${filesSummary.map((file) => `${file.name} (${file.pages} pages)`).join(', ')}`,
    result.pageRanges ? `Pages selected: ${result.pageRanges}` : '',
    `Output pages: ${result.pages}`,
    `Output file: ${result.outputName}`,
    `Download URL: ${result.outputUrl}`,
    '',
    'Adobe-style behavior:',
    '- Browser uploads PDFs to backend.',
    '- Backend reads pages with a pure Node PDF engine.',
    '- Backend creates a new downloadable PDF file.',
    '- Run metadata is stored in PostgreSQL when DATABASE_URL is configured.',
  ].filter(Boolean).join('\n');

  return {
    ok: true,
    toolId: result.action === 'split' ? 'split' : 'merge',
    title: result.title,
    type: 'real-pdf-studio',
    text,
    filename: result.outputName,
    resultUrl: result.outputUrl,
    downloadUrl: result.outputUrl,
    outputBytes: result.outputBytes,
    pages: result.pages,
    files: filesSummary,
    fallback: false,
    apiReady: true,
    realEngineReady: true,
    providerConfigured: true,
    cpanelSafe: true,
    nextSteps: [
      'Open the download link and verify page order.',
      'Store the PDF URL/path in PostgreSQL for customer history.',
      'Add watermark/signature/password features as the next Adobe-style modules.',
    ],
  };
}

module.exports = {
  runPdfStudio,
  parsePageSelection,
};
