const fs = require('fs/promises');
const path = require('path');
const { pool, query } = require('./db');

const dataDir = path.join(__dirname, '..', '..', 'data');
const toolRunsPath = path.join(dataDir, 'tool-runs.json');

async function readJson(filePath, fallback) {
  try {
    return JSON.parse(await fs.readFile(filePath, 'utf8'));
  } catch (error) {
    return fallback;
  }
}

async function writeJson(filePath, value) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, JSON.stringify(value, null, 2));
}

function warnNonCriticalWrite(error, label) {
  if (process.env.NODE_ENV !== 'test') {
    console.warn(`SANSA ${label} skipped: ${error.message}`);
  }
}

function normalizeRun(userId, output = {}, input = {}) {
  return {
    id: output.id || `tool-run-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
    userId: String(userId || 'guest'),
    toolId: String(output.toolId || input.toolId || input.action || 'unknown'),
    title: String(output.title || ''),
    workflowType: String(output.type || output.group || ''),
    prompt: String(input.prompt || ''),
    outputText: String(output.text || output.reply || output.message || ''),
    filename: String(output.filename || ''),
    fallback: Boolean(output.fallback),
    providerConfigured: Boolean(output.providerConfigured || output.providerReady),
    runJson: output,
    createdAt: new Date().toISOString(),
  };
}

async function saveToolRun(userId, output = {}, input = {}) {
  const run = normalizeRun(userId, output, input);

  if (pool) {
    try {
      const result = await query(
        `INSERT INTO tool_runs
          (user_id, tool_id, title, workflow_type, prompt, output_text, filename, fallback, provider_configured, run_json)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
         RETURNING id, created_at`,
        [
          run.userId,
          run.toolId,
          run.title,
          run.workflowType,
          run.prompt,
          run.outputText,
          run.filename,
          run.fallback,
          run.providerConfigured,
          JSON.stringify(run.runJson),
        ]
      );
      return {
        ...run,
        id: String(result.rows[0]?.id || run.id),
        createdAt: result.rows[0]?.created_at || run.createdAt,
      };
    } catch (error) {
      warnNonCriticalWrite(error, 'tool run database write');
    }
  }

  try {
    const runs = await readJson(toolRunsPath, []);
    runs.unshift(run);
    await writeJson(toolRunsPath, runs.slice(0, 1000));
  } catch (error) {
    warnNonCriticalWrite(error, 'tool run file write');
  }

  return run;
}

async function listToolRuns(userId = 'guest', limit = 25) {
  const safeLimit = Math.min(Math.max(Number(limit) || 25, 1), 100);
  if (pool) {
    const result = await query(
      `SELECT id, user_id, tool_id, title, workflow_type, prompt, output_text, filename,
              fallback, provider_configured, created_at
       FROM tool_runs
       WHERE user_id = $1
       ORDER BY created_at DESC
       LIMIT $2`,
      [String(userId || 'guest'), safeLimit]
    );
    return result.rows.map((row) => ({
      id: String(row.id),
      userId: row.user_id,
      toolId: row.tool_id,
      title: row.title,
      workflowType: row.workflow_type,
      prompt: row.prompt,
      outputText: row.output_text,
      filename: row.filename,
      fallback: row.fallback,
      providerConfigured: row.provider_configured,
      createdAt: row.created_at,
    }));
  }

  const runs = await readJson(toolRunsPath, []);
  return runs.filter((run) => run.userId === String(userId || 'guest')).slice(0, safeLimit);
}

module.exports = {
  saveToolRun,
  listToolRuns,
};
