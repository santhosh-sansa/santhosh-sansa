const SKILL_KNOWLEDGE_PACKS = [
  {
    id: 'financial-models',
    title: 'Financial Modeling Suite',
    group: 'Finance',
    icon: 'FM',
    provider: 'Local Python / Spreadsheet optional',
    sourcePack: 'Skill/anthropics-creating-financial-models.zip',
    sourceFiles: ['creating-financial-models/SKILL.md', 'creating-financial-models/dcf_model.py', 'creating-financial-models/sensitivity_analysis.py'],
    mappedTools: ['business-os', 'cfo', 'invoice', 'xlsx', 'reports'],
    triggers: ['financial model', 'dcf', 'valuation', 'sensitivity', 'scenario', 'cash flow', 'cfo'],
    accepts: 'Revenue, margins, capex, working capital, discount rate, scenarios',
    action: 'Build DCF, sensitivity, scenario planning, and CFO decision workflows.',
    samples: ['shop business valuation model create pannu', 'invoice revenue forecast DCF pannu'],
    knowledge: [
      'Use DCF analysis for valuation: historical statements, revenue growth, operating margins, capex, working capital, terminal value, WACC.',
      'Use sensitivity analysis to test important assumptions such as growth, margin, discount rate, customer churn, collection delay, and payment conversion.',
      'Use best/base/worst case planning for business-os and AI CFO outputs.',
      'For SANSA tools, connect invoice/payment history to revenue forecast and cash collection reminders.',
    ],
  },
  {
    id: 'docx-office',
    title: 'DOCX Word Builder',
    group: 'Documents',
    icon: 'DOC',
    provider: 'Office XML / LibreOffice optional',
    sourcePack: 'Skill/anthropics-docx.zip',
    sourceFiles: ['docx/SKILL.md', 'docx/scripts/office/unpack.py', 'docx/scripts/office/pack.py', 'docx/scripts/comment.py'],
    mappedTools: ['docx', 'word-pdf', 'legal', 'resume', 'quote'],
    triggers: ['word', 'docx', 'document', 'resume', 'agreement', 'proposal', 'redline'],
    accepts: '.docx files, text drafts, templates, tracked changes',
    action: 'Create, read, edit, comment, validate, and repack Word documents.',
    samples: ['rental agreement docx build pannu', 'resume docx professional format create pannu'],
    knowledge: [
      'A DOCX file is a ZIP archive containing XML files.',
      'For reading content, convert with pandoc or unpack raw XML.',
      'For editing existing DOCX, unpack, edit XML, validate, and repack.',
      'For SANSA, use this knowledge for Legal PDF, Resume, Word to PDF, proposal, quotation, and document editing flows.',
    ],
  },
  {
    id: 'pdf-processing',
    title: 'PDF Processing Guide',
    group: 'PDF',
    icon: 'PDF',
    provider: 'pdf-lib / pypdf / provider APIs',
    sourcePack: 'Skill/anthropics-pdf.zip',
    sourceFiles: ['pdf/SKILL.md', 'pdf/forms.md', 'pdf/reference.md', 'pdf/scripts/fill_fillable_fields.py'],
    mappedTools: ['pdf-studio', 'merge', 'split', 'extract', 'rotate', 'watermark', 'redact', 'pdf-word'],
    triggers: ['pdf', 'merge', 'split', 'extract', 'rotate', 'watermark', 'form', 'ocr'],
    accepts: '.pdf files, page ranges, form fields, extraction requests',
    action: 'Read, merge, split, extract, rotate, fill forms, validate fields, and produce PDF output.',
    samples: ['invoice and proof merge pannu', 'agreement page 1-3 extract pannu'],
    knowledge: [
      'PDF work starts with page count, page ranges, forms/fields, and output validation.',
      'Merge means copy pages from each source file into a new PDF.',
      'Split/extract means copy selected pages into a new output PDF.',
      'For SANSA, this maps directly to Advanced PDF Merge + Split and future forms/OCR/redaction tools.',
    ],
  },
  {
    id: 'pptx-office',
    title: 'PPTX Presentation Builder',
    group: 'Documents',
    icon: 'PPT',
    provider: 'PPTX XML / pptxgenjs optional',
    sourcePack: 'Skill/anthropics-pptx.zip',
    sourceFiles: ['pptx/SKILL.md', 'pptx/editing.md', 'pptx/pptxgenjs.md', 'pptx/scripts/add_slide.py'],
    mappedTools: ['pptx', 'products', 'portfolio', 'business-os'],
    triggers: ['pptx', 'presentation', 'pitch deck', 'slides', 'deck'],
    accepts: '.pptx files, topics, slide counts, brand notes',
    action: 'Create slide outlines, edit presentations, generate thumbnails, and build pitch decks.',
    samples: ['invoice app pitch deck 8 slides', 'portfolio presentation create pannu'],
    knowledge: [
      'Analyze PPTX through thumbnails, extracted text, and raw XML.',
      'Editing workflow: analyze template, unpack, manipulate slides, clean, and pack.',
      'From scratch workflow can use pptxgenjs-style layout planning.',
      'For SANSA, apply to product portfolio, business proposal, and marketing decks.',
    ],
  },
  {
    id: 'xlsx-office',
    title: 'XLSX Spreadsheet Builder',
    group: 'Documents',
    icon: 'XLS',
    provider: 'Spreadsheet XML / formulas optional',
    sourcePack: 'Skill/anthropics-xlsx.zip',
    sourceFiles: ['xlsx/SKILL.md', 'xlsx/scripts/recalc.py', 'xlsx/scripts/office/validate.py'],
    mappedTools: ['xlsx', 'invoice', 'reports', 'cfo', 'business-os'],
    triggers: ['xlsx', 'excel', 'spreadsheet', 'ledger', 'gst report', 'financial model'],
    accepts: '.xlsx, .xlsm, .csv, table data, formulas',
    action: 'Create clean spreadsheets, financial models, ledgers, GST reports, and zero-error formula outputs.',
    samples: ['customer ledger xlsx create pannu', 'GST sales purchase report spreadsheet pannu'],
    knowledge: [
      'Spreadsheet outputs need professional fonts, zero formula errors, and clear formatting.',
      'Financial model convention: blue input cells, black formulas, green internal links, red external links, yellow assumption highlights.',
      'Use correct formatting for years, currency, percentages, multiples, and negative numbers.',
      'For SANSA, apply to invoice ledgers, GST reports, CFO dashboard exports, and customer balances.',
    ],
  },
  {
    id: 'skill-creator-pack',
    title: 'Skill Creator Workflow',
    group: 'Developer AI',
    icon: 'SK',
    provider: 'Local skill design',
    sourcePack: 'Skill/anthropics-skill-creator.zip',
    sourceFiles: ['skill-creator/SKILL.md', 'skill-creator/references/schemas.md', 'skill-creator/scripts/package_skill.py'],
    mappedTools: ['skill-creator', 'agent-development', 'automation-recommender'],
    triggers: ['create skill', 'skill.md', 'agent', 'evaluation', 'benchmark', 'workflow'],
    accepts: 'Skill goal, triggers, workflow, examples, evaluation prompts',
    action: 'Design, improve, validate, and package new SANSA skills.',
    samples: ['GST filing skill create pannu', 'invoice reviewer agent build pannu'],
    knowledge: [
      'Skill creation loop: decide purpose, draft skill, create test prompts, evaluate, improve, repeat.',
      'Use clear descriptions and trigger rules so the correct skill activates.',
      'Keep language simple when the user is non-technical.',
      'For SANSA, this becomes the internal Skill Builder for adding new tool-specific knowledge.',
    ],
  },
  {
    id: 'image-magick-pack',
    title: 'Image Manipulation Skill',
    group: 'Creative',
    icon: 'IMG',
    provider: 'ImageMagick optional',
    sourcePack: 'Skill/github-image-manipulation-image-magick.zip',
    sourceFiles: ['image-manipulation-image-magick/SKILL.md'],
    mappedTools: ['creative-image', 'creative-photo', 'image-studio', 'stock'],
    triggers: ['image', 'resize', 'thumbnail', 'convert', 'metadata', 'wallpaper'],
    accepts: 'Image files, output size, format, batch options',
    action: 'Resize, convert, inspect metadata, create thumbnails, and batch process images.',
    samples: ['poster image thumbnail create pannu', 'product photo resize 1080x1080'],
    knowledge: [
      'Core image tasks: dimensions, metadata, resizing, format conversion, thumbnail creation, and batch processing.',
      'ImageMagick may be required for live server execution; SANSA should keep provider/fallback notes when not installed.',
      'For SANSA, connect to Creative Studio, Photo Editing, Stock Assets, and social content tools.',
    ],
  },
  {
    id: 'prd-pack',
    title: 'Product Requirements Document Builder',
    group: 'Product',
    icon: 'PRD',
    provider: 'Local product knowledge',
    sourcePack: 'Skill/github-prd.zip',
    sourceFiles: ['prd/SKILL.md'],
    mappedTools: ['products', 'business-os', 'assistant', 'product-enterprise-support'],
    triggers: ['prd', 'requirements', 'feature spec', 'product plan', 'user stories'],
    accepts: 'Problem, users, success metrics, constraints, feature idea',
    action: 'Generate executive summary, user stories, technical specs, non-goals, risks, and acceptance criteria.',
    samples: ['PDF merge tool PRD write pannu', 'invoice builder requirements create pannu'],
    knowledge: [
      'PRD workflow: discovery interview, analysis/scoping, technical drafting.',
      'Ask for core problem, success metrics, constraints, users, user flow, and non-goals.',
      'Use PRDs to turn vague SANSA ideas into implementation-ready tool specs.',
    ],
  },
  {
    id: 'ui-ux-pro-max-pack',
    title: 'UI/UX Pro Max Design Intelligence',
    group: 'Design',
    icon: 'UX',
    provider: 'Local design intelligence',
    sourcePack: 'Skill/nextlevelbuilder-ui-ux-pro-max.zip',
    sourceFiles: ['ui-ux-pro-max/SKILL.md', 'ui-ux-pro-max/data', 'ui-ux-pro-max/scripts'],
    mappedTools: ['frontend-design', 'theme-factory', 'web-design-reviewer', 'products'],
    triggers: ['ui', 'ux', 'design', 'dashboard', 'component', 'layout', 'accessibility'],
    accepts: 'Page goals, product type, brand style, target users, screenshots',
    action: 'Choose layout, color, typography, interaction, responsive, and accessibility rules.',
    samples: ['Adobe style dashboard improve pannu', 'mobile PDF upload UI design pannu'],
    knowledge: [
      'Use when designing pages, dashboards, modals, forms, tables, charts, navigation, and responsive UI.',
      'Covers style direction, color palettes, font pairings, product types, UX guidelines, chart types, and stack-specific decisions.',
      'For SANSA, apply to Adobe-style PDF Studio, invoice builder, admin, and mobile-first tool workflows.',
    ],
  },
];

function packText(pack) {
  return [
    pack.title,
    pack.group,
    pack.provider,
    pack.sourcePack,
    pack.mappedTools.join(' '),
    pack.triggers.join(' '),
    pack.accepts,
    pack.action,
    pack.samples.join(' '),
    pack.knowledge.join(' '),
  ].join(' ').toLowerCase();
}

function scorePack(query, pack) {
  const terms = String(query || '').toLowerCase().split(/[^\p{L}\p{N}_]+/u).filter((term) => term.length >= 2);
  const haystack = packText(pack);
  return terms.reduce((score, term) => score + (haystack.includes(term) ? 1 : 0), 0);
}

function skillKnowledgeCatalog() {
  return SKILL_KNOWLEDGE_PACKS.map((pack) => ({ ...pack, knowledge: [...pack.knowledge], sourceFiles: [...pack.sourceFiles], mappedTools: [...pack.mappedTools] }));
}

function knowledgeForSkill(skillId = '') {
  const id = String(skillId || '').toLowerCase();
  return SKILL_KNOWLEDGE_PACKS.filter((pack) => (
    pack.id === id
    || pack.mappedTools.includes(id)
    || pack.triggers.some((trigger) => id.includes(trigger.replace(/\s+/g, '-')))
  ));
}

function searchSkillKnowledge(query = '', limit = 6) {
  const text = String(query || '').trim();
  if (!text) return [];
  return SKILL_KNOWLEDGE_PACKS
    .map((pack) => ({
      ...pack,
      score: scorePack(text, pack),
      type: 'skill-pack',
      category: pack.group,
      keywords: [...pack.triggers, ...pack.mappedTools].join(' '),
      content: pack.knowledge.join('\n'),
    }))
    .filter((pack) => pack.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

module.exports = {
  SKILL_KNOWLEDGE_PACKS,
  skillKnowledgeCatalog,
  knowledgeForSkill,
  searchSkillKnowledge,
};
